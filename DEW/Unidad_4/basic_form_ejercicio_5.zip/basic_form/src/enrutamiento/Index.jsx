import Inicio from './Inicio'
import Centro from './Centro'
import Ciclo from './Ciclo'
import Curso from './Curso'

export default {
    Inicio, Centro, Ciclo, Curso
};